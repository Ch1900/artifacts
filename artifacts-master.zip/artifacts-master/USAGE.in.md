Travis CI Artifacts Uploader Usage
==================================

___GENERATED_WARNING___

## global options

___USAGE___

## upload

The upload commmand may be used to upload arbitrary files to an artifact
repository.  The only such artifact repository currently supported is
S3.  All of the required arguments may be provided as command line
arguments or environment variables.

___UPLOAD_USAGE___

<!-- ___CHECKSUM___ -->
