package artifact

// Result contains some lame simple crap about things done with artifacts
type Result struct {
	OK  bool
	Err error
}
